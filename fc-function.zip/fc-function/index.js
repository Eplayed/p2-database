const { runCrawler } = require('./translate_crawler');
const uploadToOss = require('./upload_to_oss');

// 定义 OSS 存储前缀 (根据环境)
// 如果 NODE_ENV 是 production，传到 release/，否则 dev/
const OSS_TARGET_PREFIX = process.env.NODE_ENV === 'production' ? 'release/' : 'dev/';

exports.handler = async (event, context, callback) => {
    console.log("🔔 [FC] 定时任务触发");
    
    try {
        // 1. 执行爬虫，返回数据生成的临时目录
        const dataDir = await runCrawler();
        
        // 2. 执行上传
        await uploadToOss(dataDir, OSS_TARGET_PREFIX);
        
        callback(null, 'Task Configured and Executed Successfully');
    } catch (error) {
        console.error("❌ [FC] 任务执行失败:", error);
        callback(error);
    }
};